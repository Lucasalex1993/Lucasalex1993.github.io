# KoiBank

### Aparecida de Freitas Rodrigues Cunha      RA 202108461725 
### Gabriel Girotto Zambaldi   RA 202212039511 
### Renato Hidaka Matos RA202302382452
### Daniel Amaral Pereira RA 202302382142
### Lucas Teixeira Alexandre RA 202211299935

# SOBRE O PROJETO:

## Nosso projeto é um banco digital, onde temos cadastros de clientes, programas de benefícios, consultoria, rendimentos, e investimentos.
#### O projeto está sendo feito utilizando as linguagens padrão: HTML5, CSS e Javascript, python sendo adaptável para qualquer tela sendo computador, notebook, ou celulares.
#### Na pasta index.html se encontra os códigos da página de apresentação do nosso projeto KoiBank;

## Dentro da pasta HTML: 
#### Temos as página de login onde o cliente entra em sua conta,Login.html 
#### Temos também o logo do nosso projeto, 
#### Temos a página de abertura de conta onde o cliente faz o seu cadastro e cria a sua conta, Abertura_conta.html
#### Temos a página de apresentação dos integrantes do grupo, Koibank.html
#### Temos a página principal do projeto acessando através do Tema.

## Dentro da pasta Acesso, contém Home Koi Bank.pdf e Pagina abertura de conta Koi Bank.pdf foi criado no figma, onde fizemos o layout da página do nosso projeto.
#### Tela inicial: https://gabrielzambaldi.github.io/KoiBank/.
#### Tela de Tema: https://gabrielzambaldi.github.io/KoiBank/HTML/Tema.html.
#### Tela de abertura de conta: https://gabrielzambaldi.github.io/KoiBank/HTML/Abertura_conta.html.
#### Tela de Login: https://gabrielzambaldi.github.io/KoiBank/HTML/Login.html.
#### Tela sobre nós: https://gabrielzambaldi.github.io/KoiBank/HTML/Koibank.html.
